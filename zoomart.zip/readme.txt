Content Plugin zoomart version 1.0.0  is a free software which is developed by
KWProductions Co.
The license is GNU/GPLv3
It is written for joomla 3.x, joomla 4 alpha and betta, fill all formfields in 
the plugin to make it work, you can exclude images in a webpage to prevent them from being zoomed by inputing direct
class images in plugin backend, in the next version direct class path shall work too(e.g div a img), also we shall 
design it for touchmove event and responsiveness in the following versions!
We remind you images in galleries usually accompany some events like hovering and etc, the plugin won't effect on 
images of this type.
you may download the extension @:
https://www.extensions.kwproductions121.com/myplugins/zoomart.html
In case of any problem contact me at:
webarchitect@kwproductions121.com
https://github.com/KianWilliam/Zoomart.git
long live science.